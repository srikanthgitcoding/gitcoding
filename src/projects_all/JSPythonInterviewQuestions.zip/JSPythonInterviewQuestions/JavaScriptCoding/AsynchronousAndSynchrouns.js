console.log("1")
console.log("2")
console.log("3")


console.log("4")
setTimeout(() => {
    console.log("5")
},1000)
console.log("6")


// Synchrounous code is blocking. one must complete before anythong can happen
// asynchrouns code is not bloicking