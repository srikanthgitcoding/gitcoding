var arr =[1,2,43]

console.log(typeof(arr))

console.log( Array.isArray(arr))

console.log( arr.constructor === Array )
