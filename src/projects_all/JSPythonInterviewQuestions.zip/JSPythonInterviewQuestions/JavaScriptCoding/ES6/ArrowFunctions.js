function fn(){
    return 2*2
}

fn()


const fn = () => 2*2