// Operators and Operands
// The numbers (in an arithmetic operation) are called operands.

// The operation (to be performed between the two operands) is defined by an operator.

// Operand	 Operator	Operand
// 100	        +	          50