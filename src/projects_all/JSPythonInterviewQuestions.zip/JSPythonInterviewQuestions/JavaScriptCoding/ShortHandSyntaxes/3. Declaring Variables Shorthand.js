//1
let x;
let y;
let z = 3;

//2

let x, y, z=3;


