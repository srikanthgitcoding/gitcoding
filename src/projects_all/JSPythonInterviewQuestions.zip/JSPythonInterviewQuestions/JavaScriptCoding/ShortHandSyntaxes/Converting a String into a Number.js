const num1 = parseInt("100");
const num2 =  parseFloat("100.01");


const num1 = +"100"; // converts to int data type
const num2 =  +"100.01"; // converts to float data type