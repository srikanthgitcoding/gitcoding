//The unary + operator can be used to convert a variable to a number:

var y = "5";      // y is a string
var x = + y;      // x is a number