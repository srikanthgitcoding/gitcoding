console.log(1 < 2 < 3);
console.log(3 > 2 > 1);

var a = [1,2,3]
a[10]= 10

// console.log(a)
console.log(a[6]);