function foo1()
{
  return {
      bar: "hello"
  };
}
console.log(foo1())
function foo2()
{
  return 
  {
      bar: "hello"
  };
}
console.log(foo2())
