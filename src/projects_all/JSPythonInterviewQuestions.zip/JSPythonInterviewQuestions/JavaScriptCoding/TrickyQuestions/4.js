console.log(0.1 + 0.2);
console.log(0.1 + 0.2 == 0.3);