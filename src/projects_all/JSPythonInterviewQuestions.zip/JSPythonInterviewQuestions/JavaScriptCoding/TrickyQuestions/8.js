console.log(false == '0')
console.log(false === '0')