var a={}, b={key:'b'}, c={key:'c'};

console.log(a) 
a[b]=123;
a[c]=456;
console.log(a)

console.log(a[b]);
