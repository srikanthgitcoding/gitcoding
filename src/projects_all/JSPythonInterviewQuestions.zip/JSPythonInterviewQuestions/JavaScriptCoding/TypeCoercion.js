console.log("Hello" + 8)// Hello 8
console.log('8' + 8) // true

// Type coercion is the process of converting value from one
//  type to another (such as string to number, object to boolean, and so on).