let words = ['spray', 'limit', 'exuberant', 'destruction','elite', 'present']

let n=[1,2,3,4,5,6,7,8,9]
n.filter((i)=>{
    if (i%2 == 0){
        console.log(i)
    } 
    
})