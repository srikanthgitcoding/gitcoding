for (let i=1; i <5 ; i++)
{
console.log("check")
}
console.log(Array())

arr = [1,2,3,4,5]

for (let i in arr){
    console.log(i)
}

for (let i of arr){
    console.log(i)
}