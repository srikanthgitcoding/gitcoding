var x = 5

var fn = function(){
    (function(){
    console.log(x)
    var x= 15
    })();

}

fn()