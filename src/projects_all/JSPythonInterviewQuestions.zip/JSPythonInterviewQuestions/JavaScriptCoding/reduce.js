var l= [1,2,3,4,5,6,7]
const x =l.reduce((total,num)=>{
    
    return total+ num

})
console.log(x)