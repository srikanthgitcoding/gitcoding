var s = "srikanth"
len = s.length
rev =''

for(let i=0; i< len; i++){
    rev = s[i] + rev
}

console.log(rev)