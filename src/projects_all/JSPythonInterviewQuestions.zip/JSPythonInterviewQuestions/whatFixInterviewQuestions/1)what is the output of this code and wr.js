// 1)what is the output of this code?
//     for (var i = 1; i <= 3; i++) {
//         setTimeout(function() { 
//             console.log(index); 
//         },0);
//     } 
//     I answred the output correctly.
//     i) Write code to correct it without using let?

// 2)Write Output of the following code: 

//     console.log('start');

//     setTimeout(function() {
//     console.log('setTimeout');
//     }, 0);

//     Promise.resolve().then(function() {
//     console.log('promise 1');
//     }).then(function() {
//     console.log('promise 2');
//     });

//     console.log('end');

//     i) why Promise Output After SetTimeout? 

// I answred this question    

// 3)Write a code for the following :

// <div data-tooltip=”true” data-tooltip-width=”100px” data-tooltip-content=”<p>Test</p>”>.......</div>
// <span data-tooltip=”true” data-tooltip-width=”200px” data-tooltip-content=””>.......</span>

// <img src=””  data-tooltip=”true” data-tooltip-width=”50px” data-tooltip-content=”” />

// <div data-tooltip=”true” data-tooltip-width=”50px” data-tooltip-content=” ” >

// </div>

// i) Add an event listener method "onmouseover" to all the above elements (not hardcoded) - written code for this.
// ii)On mouseover if data-tooltip is true show a tooltip with content - written code for this.
// iii)Write tooltip css code and When tooltip is visisble ui should not interupted because of positioning - written code for this.
// iv)on scroll up and down ui shouldn't be distrubed - gave solution how to resolve it and he said yes it is correct,partially written the code.






