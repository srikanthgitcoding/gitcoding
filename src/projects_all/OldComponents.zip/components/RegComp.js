import React, { Component } from 'react';

class RegComp extends Component {
    render() {
        console.log("reg components")

        return (
            <div>
                reg components
            </div>
        );
    }
}

export default RegComp;